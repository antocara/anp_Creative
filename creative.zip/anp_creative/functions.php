<?php 
add_action('after_setup_theme', 'anp_conf_theme');
	function anp_conf_theme() {
		global $content_width;
		/**** ancho mínimo ****/
		if ( ! isset( $content_width ) ) 
			$content_width = 650;
		/**** cargo página de opciones ****/	
		require_once ( get_template_directory() . '/theme-options.php' );
		/**** cargo shortcodes ****/	
		require_once ( get_template_directory() . '/shortcodes/shortcode.php' );
		/**** estilos para editor texto ****/	
		add_editor_style();
		/**** imágenes de fondo ****/
		add_custom_background();	
		/**** activamos thumbnails ****/
		add_theme_support( 'post-thumbnails' );
		/**** activamos el feed ****/
		add_theme_support('automatic-feed-links'); 	
		/**** longitud personalizada de excerpt ****/	
		add_filter( 'excerpt_length', 'anp_creative_custom_excerpt_length');
		/**** texto personalizado de excerpt ****/
		add_filter('excerpt_more', 'anp_creative_new_excerpt_more');	
		/**** registramos los sidebar ****/
		add_action('widgets_init', 'anp_creative_reg_sideb');
		/**** registramos los menus ****/
		add_action('init', 'anp_creative_reg_nav');
		/**** añadimos hoja estilos explor ****/
		add_action('wp_head', 'anp_creative_estilos_explor');
		/**** añadimos hoja estilos shortcode ****/
		add_action('wp_head', 'anp_creative_estilos_shortcode');
		
	}
	
function anp_creative_reg_sideb() {  /**** activamos los sidebar ****/
	
    register_sidebar(array( #registramos una zona de widgets nueva
		'name' => 'sidebar', #le indicamos el nombre
        'before_widget' => '<div id="%1$s" class="widget_sid %2$s">', #indicamos el html que aparecerá justo antes de poner los widgets y justo después.
        'after_widget' => '</div>',
        'before_title' => '<h3>', #le indicamos el html que aparece justo antes de escribir el título del widget y justo despues.
        'after_title' => '</h3>',
    ));
    register_sidebar(array( #registramos una zona de widgets nueva
    	'name' => 'footer1', #le indicamos el nombre
        'before_widget' => '<div  id="%1$s" class="widget_pie %2$s">', #indicamos el html que aparecerá justo antes de poner los widgets y justo después.
        'after_widget' => '</div>',
        'before_title' => '<h3>', #le indicamos el html que aparece justo antes de escribir el título del widget y justo despues.
        'after_title' => '</h3>',
    )); 
    register_sidebar(array( #registramos una zona de widgets nueva
    	'name' => 'footer2', #le indicamos el nombre
        'before_widget' => '<div id="%1$s" class="widget_pie %2$s">', #indicamos el html que aparecerá justo antes de poner los widgets y justo después.
        'after_widget' => '</div>',
        'before_title' => '<h3>', #le indicamos el html que aparece justo antes de escribir el título del widget y justo despues.
        'after_title' => '</h3>',
    ));      
 }
   
function anp_creative_reg_nav() {  /**** activamos un menú ****/
 	
  	register_nav_menus(
 		array(
 		  'menu_header_1' => 'menu1',
 	)); 
 }	
 
function anp_creative_custom_excerpt_length( $length ) {  /**** modificamos número palabras excerpt ****/
 	return 30;
 }


function anp_creative_paginado() { /**** función de paginado ****/
     global $wp_query, $wp_rewrite;
     $wp_query->query_vars['paged'] > 1 ? $current = $wp_query->query_vars['paged'] : $current = 1;
  
     $pagination = array(
         'base' => @add_query_arg('page','%#%'),
         'format' => '',
         'total' => $wp_query->max_num_pages,
         'current' => $current,
         'show_all' => true,
         'type' => 'list',
         'next_text' => '&raquo;',
         'prev_text' => '&laquo;'
         );
  
     if( $wp_rewrite->using_permalinks() )
         $pagination['base'] = user_trailingslashit( trailingslashit( remove_query_arg( 's', get_pagenum_link( 1 ) ) ) . 'page/%#%/', 'paged' );
  
     if( !empty($wp_query->query_vars['s']) )
         $pagination['add_args'] = array( 's' => get_query_var( 's' ) );
  
     echo paginate_links( $pagination );
 }
 
function anp_creative_idiomas(){ /**** soporte a multidiomas ****/
     load_theme_textdomain('anp_creative', get_template_directory() . '/languages');
        
 }
 add_action('after_setup_theme', 'anp_creative_idiomas');
 
 
function anp_creative_new_excerpt_more($more) { /**** texto personalizado al final del excerpt ****/
        global $post;
 	return '   <a href="'. get_permalink($post->ID) . '">' . __('Read more', 'anp_creative').'</a>';
 }

 
function anp_creative_estilos_explor() {  /**** añado a head hoja de estilos para Explor  ****/
     wp_register_style( 'ie8', get_template_directory_uri() . 'style-ie.css', true );
     $GLOBALS['wp_styles']->add_data( 'ie8', 'conditional', 'lte IE 8' );   
     wp_enqueue_style( 'ie8' );  
 }
  
function anp_creative_estilos_shortcode() {  /**** añado a head hoja de estilos para shortcode  ****/
     wp_register_style( 'short', get_template_directory_uri() . '/shortcodes/style_shortcode.css' );  
     wp_enqueue_style( 'short' );  
 }
  

function anp_creative_mis_scripts() {  /**** cargo Jquery de google  ****/
    wp_deregister_script( 'anp_instpress_jquery' );
    wp_register_script( 'anp_instpress_jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js');
    wp_enqueue_script( 'anp_instpress_jquery' );
    
     /**** cargo efecto en menús  ****/
    wp_register_script( 'anp_instpress_menuh', get_template_directory_uri() . '/js/menuh.js');
    wp_enqueue_script( 'anp_instpress_menuh' );
    
    /**** cargo arrows menus  ****/
    wp_register_script( 'anp_instpress_arrows', get_template_directory_uri() . '/js/arrows_menu.js');
    wp_enqueue_script( 'anp_instpress_arrows' );

}    
 
add_action('wp_enqueue_scripts', 'anp_creative_mis_scripts');

/****** incluyo widgets *********/     
require_once ( get_template_directory() . '/widgets/twitter.php' ); 
require_once ( get_template_directory() . '/widgets/flickr.php' ); 
require_once ( get_template_directory() . '/widgets/ads.php' ); 

/******* chekea actualizaciones ********/
require_once ( get_template_directory() . '/update/theme-update-checker.php' );

$example_update_checker = new ThemeUpdateChecker(
    'creative',
    'https://github.com/anpstudio/anp_Creative/blob/master/update.json'
);

 ?>