<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<title><?php wp_title(); ?> <?php bloginfo( 'name' ); ?></title>
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="stylesheet" href="<?php bloginfo( 'stylesheet_url' ); ?>" type="text/css" media="screen" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
	<?php if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' ); ?>


		<!--[if lt IE 9]>
			<script src="http://ie7-js.googlecode.com/svn/version/2.1(beta4)/IE9.js"></script> //hack para que IE8 entienda html5
		<![endif]-->

	<?php wp_head(); ?> <!-- hook de Wordpress-->
</head>

<body <?php body_class(); ?>>
	<div id="cont_gen">	
		<header id="cab">
			<div id="cab_fond_iz"></div>
			<div id="cont_ind_head">
				<div id="logo">
					<h1><a href="<?php echo home_url(); ?>"><?php bloginfo('name'); ?></a></h1>
				</div>
				<nav id="men_cab">
						<?php wp_nav_menu( array( 'theme_location' => 'menu_header_1', 'container' =>'' ) ); ?>
				</nav>
			</div>	
			<div id="cab_fond_der"></div>
		</header>