<?php 
function successbox($atts, $content=null, $code="") {
 
    $return = '<div class="success">';
    $return .= $content;
    $return .= '</div>';
    return $return;
}
add_shortcode('success' , 'successbox' );

function alertbox($atts, $content=null, $code="") {
 
    $return = '<div class="alert">';
    $return .= $content;
    $return .= '</div>';
    return $return;
}
add_shortcode('alert' , 'alertbox' );

function stopbox($atts, $content=null, $code="") {
 
    $return = '<div class="stop">';
    $return .= $content;
    $return .= '</div>';
    return $return;
}
add_shortcode('stop' , 'stopbox' );

function quotebox($atts, $content=null, $code="") {
 
    $return = '<div class="quote">';
    $return .= $content;
    $return .= '</div>';
    return $return;
}
add_shortcode('quote' , 'quotebox' );

function one_half( $atts, $content = null ) {
   return '<div class="one_half">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_half', 'one_half');
 
function one_half_last( $atts, $content = null ) {
   return '<div class="one_half last">' . do_shortcode($content) . '</div>
   <div class="clearboth"></div>';
} 
add_shortcode('one_half_last', 'one_half_last');


?>