function arrow_menu(){

	$("#men_cab ul li:has(ul)").addClass("arrow");
	
	
}

$(document).ready(function(){
	arrow_menu();
	
});	
	