function cwmainmenu(){
//$(" #nav_sup ul ").css({display: "none"}); // Opera Fix
$(" #men_cab li").hover(function(){
		$(this).find('ul:first').css({visibility: "visible",display: "none"}).show(500);
		},function(){
		$(this).find('ul:first').css({visibility: "hidden"});
		});
}

 $(document).ready(function(){
	cwmainmenu();
	
});