<footer>
			<div id="cont_ind_foot">	
				<section id="zona_widget">
					<div id="widget_uno">
						<?php if (!dynamic_sidebar('footer1') ) ?>
					</div>
					<div id="widget_dos">
						<?php if (!dynamic_sidebar('footer2') ) ?>
						
					</div>
				</section>
				<section id="social_busc">
					<div id="buscador">
						<form method="post" action="http://feedburner.google.com/fb/a/mailverify" target="popupwindow" onclick="window.open('<?php $options = get_option('anp_creative_sample_theme_options'); echo $options['anp_creative_email'];?>', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">
							<h3>Suscríbete a nuestro boletín</h3>
							<input type="email" name="susc_email" value="ingresa tu email" />
							<input type="hidden" value="Actualidadgoogle" name="uri"/><input type="hidden" name="loc" value="es_ES"/>
							<input type="button" name="enviar" value="enviar" />

						</form>
						<div class="clear"></div>
					</div>
					<div id="sociales_footer">
						<a href="<?php $options = get_option('anp_creative_sample_theme_options'); echo $options['anp_creative_facebook'];?>"><img src="<?php echo get_template_directory_uri(); ?>/images/icon_facebook.png" alt="icono_facebook" width="49" height="49"/></a>
						<a href="<?php $options = get_option('anp_creative_sample_theme_options'); echo $options['anp_creative_twitter'];?>"><img src="<?php echo get_template_directory_uri(); ?>/images/icon_twitter.png" alt="icono_twitter" width="49" height="49" /></a>
						<a href="<?php $options = get_option('anp_creative_sample_theme_options'); echo $options['anp_creative_rss'];?>"><img src="<?php echo get_template_directory_uri(); ?>/images/icon_rss.png" alt="icono_rss" width="49" height="49" /></a>
					</div>
					<div id="creditos">
						<p><?php _e('Theme', 'anp_creative');?> <a href="http://www.wordpress.org"> Wordpress</a><?php _e('developed by', 'anp_creative');?> <a href="http://www.anpstudio.com"> anpstudio</a><?php _e('and designed by', 'anp_creative');?><a href="http://www.blazrobar.com"> Blaz Robar </a></p> 
						
					</div>
					
				</section>
				<div class="clear"></div>
			</div>
		</footer>
	</div>
<?php wp_footer(); ?>	
</body>
</html>