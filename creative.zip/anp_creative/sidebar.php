<aside>	
	<div id="cont_sideb">	
		<?php if (!dynamic_sidebar('sidebar') ) ?>
	</div>
	<div id="bor_sideb"></div>
	<div id="bor_sideb2"></div>
</aside>	
	