<?php /* Comentarios anidados, paginados y comentados por Kernel Web! */ ?>
			<div id="comments_wrapper">
<?php // No borres esto, previene el acceso directo al archivo comments.php y checa si un post tiene contraseña
    if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
        die (__('Please do not upload this page directly. Thanks!', 'anp_creative'))
           
        ?>
<?php if ( have_comments() ) : /* Checa si el post tiene comentarios */ ?>
     <h3><?php comments_number(__('0 comment, be the first to review', 'anp_creative'),
     __('1 comment, Leave yours!', 'anp_creative'), '%'.__(' comments, also leave yours!', 'anp_creative'));?>
     en &#8220;<?php the_title();?>&#8221;</h3>
<div class="navigation">
         <div class="alignleft"><?php previous_comments_link(__('« Previous comments', 'anp_creative')) ?></div>
         <div class="alignright"><?php next_comments_link(__('Next comments »', 'anp_creative')) ?></div>
     </div>
     <?php /* Una lista de nuestros comentarios que pueden personalizar con la función callback en functions.php */ ?>
          <ol class="commentlist">
          <?php wp_list_comments(); ?>
          </ol>
          <?php else : /* Esto se muestra si todavia no hay comentarios en la entrada */ ?>
              <?php if ('open' == $post->comment_status) : ?>
          
          	<?php else : /* Si los comentarios estan cerrados se mostrara el siguiente mensaje */ ?>
                  <p class="nocomments"><?php _e('Comments are closed, sorry for the inconvenience. ', 'anp_creative');?></p>
              <?php endif; ?>
          <?php endif; ?>
          
          <!-- Si los comentarios estan abiertos se contruye el formulario para comentar -->
  
          
       
          <?php comment_form(); ?>
          </div><!-- #comments_wrapper -->		