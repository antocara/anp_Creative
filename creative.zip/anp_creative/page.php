<?php get_header(); ?>
<div id="cont_ind_index">	
	<section id="cont_index">		
		
		<article id="cont_page">			
			<?php while ( have_posts() ) : the_post(); ?>
				<h2>
				<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
				<?php the_title(); ?></a></h2>
			<div id="texto_page">
				<?php the_content(); ?>
			</div>
		</article>		
			<div class="comments-template">
				<?php comments_template(); ?>
			</div>
			<?php endwhile; ?>		
	
	</section>
	<?php get_sidebar(); ?> 
</div>	
<?php get_footer(); ?>	