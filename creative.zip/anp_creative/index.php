<?php get_header(); ?>	
<ul id="social_bar">
	<li id="twitter"><a href="<?php $options = get_option('anp_creative_sample_theme_options'); echo $options['anp_creative_twitter'];?>"><img src="<?php echo get_template_directory_uri(); ?>/images/twitter_icon_lat.png" alt="icon_twitter_lat" /></a></li>
	<li id="rss"><a href="<?php $options = get_option('anp_creative_sample_theme_options'); echo $options['anp_creative_rss'];?>"><img src="<?php echo get_template_directory_uri(); ?>/images/rss_icon_lat.png" alt="icon_rss_lat" /></a></li>
	<li><a href="<?php $options = get_option('anp_creative_sample_theme_options'); echo $options['anp_creative_facebook'];?>"><img src="<?php echo get_template_directory_uri(); ?>/images/facebook_icon_lat.png" alt="icon_facebook_lat" /></a></li>
</ul>
	<div id="cont_ind_index">
		<section id="cont_index">
			<?php $contador_post=0; if (have_posts()) : ?> <!--iniciamos contador-->
			<?php while (have_posts()) : $contador_post= $contador_post+1; the_post(); ?>
			<?php if ($contador_post<=5) { ?> <!--los 5 primeros post-->
			
				<article class="post_index_tip1">
					<!--imagen post-->
					<?php if(has_post_thumbnail()){ ?> <!--comprobamos que existe imagen principal en el post-->
						<div class="img_post_index_tip1">
							<?php the_post_thumbnail(array(600,500)); ?>
						</div><?php } ?>
					<div class="triangulo1"></div>	
					<div class="text_index_tip1">	
						<header class="titulo_post_index_tip1">
							<h2 id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
								<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
								<?php the_title(); ?></a></h2>
						</header>		
						<div class="meta_post_tip1">
						 	<p><?php the_time(get_option( 'date_format' )) ?></p>		
						</div>
						<content class="excert_post_index_tip1"><?php the_excerpt(); ?></content>
						 
						 <div class="pag_index_tip1"> <!-- paginación dentro de post -->
						 <?php wp_link_pages();?>
						 </div> 
						<div class="bord_tip1"></div>
						<div class="bord_tip11"></div> 
					</div>	
				</article> 
			<?php  } ?>
			<?php if ($contador_post>5) { ?>	<!--a partir del post 5 -->
			
				<article class="post_index_tip2">
					<!--imagen post-->
					<?php if(has_post_thumbnail()){ ?> <!--comprobamos que existe imagen principal en el post-->
						<div class="img_post_index_tip2">
							<?php the_post_thumbnail(array(265,300)); ?>
						</div><?php } ?>
					<div class="triangulo2"></div>	
					<div class="text_index_tip2">
						<header class="titulo_post_index_tip2">
							<h2 id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
								<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
								<?php the_title(); ?></a></h2>
						</header>		
						<div class="meta_post_tip2">
						 	<p><?php the_time(get_option( 'date_format' )) ?></p>		
						</div>
						<content class="excert_post_index_tip2"><?php the_excerpt(); ?></content>
						 
						 <div class="pag_index_tip2"> <!-- paginación dentro de post -->
						 <?php wp_link_pages();?>
						 </div> 
						<div class="bord_tip2"></div>
						<div class="bord_tip21"></div>
					</div>	 
				</article>
			
			<?php  } ?>
			<?php endwhile; ?>
				<div id="navi"><?php anp_creative_paginado(); ?>	</div><!-- paginación de post -->
				
			<?php else : ?>
				 <h2 ><?php _e('Not Found', 'anp_creative');?></h2>
				 <p><?php _e('Apologies, but we were unable to find what you were looking for', 'anp_creative'); ?></p>
										
			<?php endif; ?>
			
			
			
		</section>
		<?php get_sidebar(); ?>		
	</div>
<?php get_footer(); ?>		