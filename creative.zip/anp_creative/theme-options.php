<?php

add_action( 'admin_init', 'anp_creative_theme_options_init' );
add_action( 'admin_menu', 'anp_creative_theme_options_add_page' );

/**
 * Init plugin options to white list our options
 */
function anp_creative_theme_options_init(){
	register_setting( 'anp_creative_sample_options', 'anp_creative_sample_theme_options', 'anp_creative_theme_options_validate' );
}

/**
 * Load up the menu page
 */
function anp_creative_theme_options_add_page() {
	add_theme_page( __( 'Options Creative', 'anp_creative' ), __( 'Options Creative', 'anp_creative' ), 'edit_theme_options', 'theme_options', 'anp_creative_theme_options_do_page' );
}

/**
 * Create the options page
 */
function anp_creative_theme_options_do_page() {
	global $select_options, $radio_options;

	if ( ! isset( $_REQUEST['settings-updated'] ) )
		$_REQUEST['settings-updated'] = false;

	?>
	<div class="wrap">
		<?php screen_icon(); echo "<h2>" . get_current_theme() . __( ' Options', 'anp_creative' ) . "</h2>"; ?>

		<?php if ( false !== $_REQUEST['settings-updated'] ) : ?>
		<div class="updated fade"><p><strong><?php _e( 'Saved Settings', 'anp_creative' ); ?></strong></p></div>
		<?php endif; ?>

		<form method="post" action="options.php">
			<?php settings_fields( 'anp_creative_sample_options' ); ?>
			<?php $options = get_option( 'anp_creative_sample_theme_options' ); ?>

			<table class="form-table">


				<?php
				/**
				 * A sample text input option
				 */
				?>
				<tr valign="top"><th scope="row"><?php _e( 'Facebook User', 'anp_creative' ); ?></th>
					<td>
						<input id="anp_creative_sample_theme_options[anp_creative_facebook]" class="regular-text" type="text" name="anp_creative_sample_theme_options[anp_creative_facebook]" value="<?php esc_attr_e( $options['anp_creative_facebook'] ); ?>" />
						<label class="description" for="anp_creative_sample_theme_options[anp_creative_facebook]"><?php _e( 'Exam.- http://www.facebook.com/user', 'anp_creative' ); ?></label>
					</td>
				</tr>
				<tr valign="top"><th scope="row"><?php _e( 'Twitter User', 'anp_creative' ); ?></th>
					<td>
						<input id="anp_creative_sample_theme_options[anp_creative_twitter]" class="regular-text" type="text" name="anp_creative_sample_theme_options[anp_creative_twitter]" value="<?php esc_attr_e( $options['anp_creative_twitter'] ); ?>" />
						<label class="description" for="anp_creative_sample_theme_options[anp_creative_twitter]"><?php _e( 'Exam.- http://www.twitter.com/user', 'anp_creative' ); ?></label>
					</td>
				</tr>
				<tr valign="top"><th scope="row"><?php _e( 'Feedburner o RSS', 'anp_creative' ); ?></th>
					<td>
						<input id="anp_creative_sample_theme_options[anp_creative_rss]" class="regular-text" type="text" name="anp_creative_sample_theme_options[anp_creative_rss]" value="<?php esc_attr_e( $options['anp_creative_rss'] ); ?>" />
						<label class="description" for="anp_creative_sample_theme_options[anp_creative_rss]"><?php _e( 'Exam.- http://feeds.feedburner.com/user', 'anp_creative' ); ?></label>
					</td>
				</tr>
				<tr valign="top"><th scope="row"><?php _e( 'Suscripción email feedburner', 'anp_creative' ); ?></th>
					<td>
						<input id="anp_creative_sample_theme_options[anp_creative_email]" class="regular-text" type="text" name="anp_creative_sample_theme_options[anp_creative_email]" value="<?php esc_attr_e( $options['anp_creative_email'] ); ?>" />
						<label class="description" for="anp_creative_sample_theme_options[anp_creative_email]"><?php _e( 'Exam.- http://feedburner.google.com/fb/a/mailverify?uri=user', 'anp_creative' ); ?></label>
					</td>
				</tr>

				<?php
				/**
				 * A sample textarea option
				 */
				?>
				
			</table>

			<p class="submit">
				<input type="submit" class="button-primary" value="<?php _e( 'Save Settings', 'anp_creative' ); ?>" />
			</p>
			
		</form>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
			<input type="hidden" name="cmd" value="_s-xclick">
			<input type="hidden" name="hosted_button_id" value="Y5TG8EW2DJRF6">
			<p><?php _e('If you like this Wordpress Theme, please consider donating a buck or two by clicking the button below, thanks', 'anp_creative'); ?></p>
			<input type="image" src="https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal Ñ The safer, easier way to pay online.">
			<img alt="" border="0" src="https://www.paypalobjects.com/es_ES/i/scr/pixel.gif" width="1" height="1">
		</form>
	</div>
	<?php
}

/**
 * Sanitize and validate input. Accepts an array, return a sanitized array.
 */
function anp_creative_theme_options_validate( $input ) {
	global $select_options, $radio_options;
	// Our checkbox value is either 0 or 1
	if ( ! isset( $input['option1'] ) )
		$input['option1'] = null;
	$input['option1'] = ( $input['option1'] == 1 ? 1 : 0 );

	// Say our text option must be safe text with no HTML tags
	$input['anp_creative_facebook'] = esc_url_raw(wp_filter_nohtml_kses( $input['anp_creative_facebook'] ));
	$input['anp_creative_twitter'] = esc_url_raw(wp_filter_nohtml_kses( $input['anp_creative_twitter'] ));
	$input['anp_creative_rss'] = esc_url_raw(wp_filter_nohtml_kses( $input['anp_creative_rss'] ));
	$input['anp_creative_email'] = esc_url_raw(wp_filter_nohtml_kses( $input['anp_creative_email'] ));
	



	return $input;
}

// adapted from http://planetozh.com/blog/2009/05/handling-plugins-options-in-wordpress-28-with-register_setting/