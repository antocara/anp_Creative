<?php get_header(); ?>	
	<div id="cont_ind_index">	
		<section id="cont_index">
			
		
			<?php if (have_posts()) : ?> 
			<?php the_post(); ?>
			
			<div id="info_autor">
			   <div class="autor-foto"><?php echo get_avatar( get_the_author_meta('user_email'), '60' ); ?></div>
			   <div class="autor-nombre"><?php the_author_posts_link(); ?></div>
			   <div class="autor-bio"><?php the_author_meta( 'user_description' ); ?></div>
			
			</div>
			<?php while (have_posts()) : the_post(); ?>
						
				<article class="post_cat_tip2">
					<!--imagen post-->
					<?php if(has_post_thumbnail()){ ?> <!--comprobamos que existe imagen principal en el post-->
						<div class="img_post_cat_tip2">
							<?php the_post_thumbnail(array(200,180)); ?>
						</div><?php } ?>
					<div class="triangulo2"></div>	
					<div class="text_cat_tip2">
						<header class="titulo_post_cat_tip2">
							<h2 id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
								<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">
								<?php the_title(); ?></a></h2>
						</header>		
						<div class="meta_post_tip2">
						 	<p><?php the_time(get_option( 'date_format' )) ?></p>		
						</div>
						 
						 <div class="pag_index_tip2"> <!-- paginación dentro de post -->
						 <?php wp_link_pages();?>
						 </div> 
						<div class="bord_tip2"></div>
						<div class="bord_tip21"></div>
					</div>	 
				</article>
			
			<?php endwhile; ?>
				<div id="navi"><?php anp_creative_paginado(); ?>	</div><!-- paginación de post -->
				
			<?php else : ?>
				 <h2 ><?php _e('Not Found', 'anp_creative');?></h2>
				 <p><?php _e('Apologies, but we were unable to find what you were looking for', 'anp_creative'); ?></p>
										
			<?php endif; ?>
			
			
			
		</section>
		<?php get_sidebar(); ?>		
	</div>
<?php get_footer(); ?>	