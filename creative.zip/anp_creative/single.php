<?php get_header(); ?>	
<ul id="social_bar">
	<li id="twitter"><a href="<?php $options = get_option('anp_creative_sample_theme_options'); echo $options['anp_creative_twitter'];?>"><img src="<?php echo get_template_directory_uri(); ?>/images/twitter_icon_lat.png" alt="icon_twitter_lat" /></a></li>
	<li id="rss"><a href="<?php $options = get_option('anp_creative_sample_theme_options'); echo $options['anp_creative_rss'];?>"><img src="<?php echo get_template_directory_uri(); ?>/images/rss_icon_lat.png" alt="icon_rss_lat" /></a></li>
	<li><a href="<?php $options = get_option('anp_creative_sample_theme_options'); echo $options['anp_creative_facebook'];?>"><img src="<?php echo get_template_directory_uri(); ?>/images/facebook_icon_lat.png" alt="icon_facebook_lat" /></a></li>
</ul>
		<div id="cont_ind_index">
			<article id="cont_single">			
					<div class="post">
						<?php if (have_posts()) : ?>
						<?php while (have_posts()) : the_post(); ?>
							<!--imagen post-->
							<?php if(has_post_thumbnail()){ ?> <!--comprobamos que existe imagen principal en el post-->
								<div class="img_post">
									<?php the_post_thumbnail(array(600,500)); ?>
								</div><?php } ?>
							<!--imagen post-->	
							<div id="meta_post">
									<div id="anp_avatar"><?php echo get_avatar( get_the_author_meta('ID'), 62 ); ?><p><?php the_author_posts_link() ?></p></div>
									<div id="sep"></div>
									<div id="anp_clock"><p><?php the_time(get_option( 'date_format' )) ?></p></div>
									<div id="anp_comment"><p><?php _e('Comments:  ','anp_creative'); ?><?php comments_popup_link('0', '1', '%'); ?></p></div>											
							
							</div>
								
							<div class="triangulo_post"></div>		
							<div id="text_post"> <!--contenido post sin imagen-->	
								<h2 id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
									<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>">
									<?php the_title(); ?></a>
								</h2>
								
							
								<?php 
									
									the_content('Read the full post',true);
									
								?>
								<div id="anp_pag_post"> <!--paginación post-->
									<?php wp_link_pages();?>
								</div>
								<div class="bord_tip1"></div>
								<div class="bord_tip11"></div>	
							</div>
							 
							
							<div id="anp_etiq">
								<p><?php _e('Tags:  ','anp_creative'); ?><?php
								echo get_the_tag_list('<p> ',' ','</p>');?></p>
							
								<div id="anp_cat"><p><?php _e('Category:  ','anp_creative'); ?><?php the_category(', '); ?></p></div>
							</div>
							<div id="post_rela">
								<?php
								//para poner en el loop, muestra 5 titulos de post relacionados con la primera tag del post actual
									$tags = wp_get_post_tags($post->ID);
									if ($tags) {
									  _e('<h3>Related post</h3>', 'anp_creative');
									 $first_tag = $tags[0]->term_id;
									 $args=array(
									 'tag__in' => array($first_tag),
									 'post__not_in' => array($post->ID),
									 'showposts'=>3,
									 'caller_get_posts'=>1
									 );
									 $my_query = new WP_Query($args);
									 if( $my_query->have_posts() ) {
									 while ($my_query->have_posts()) : $my_query->the_post(); ?>
										 <div class="list_post_rela">
										 	<!--imagen post-->
										 	<?php if(has_post_thumbnail()){ ?> <!--comprobamos que existe imagen principal en el post-->
										 		<div class="img_post_rela">
										 			<?php the_post_thumbnail(array(80,80)); ?>
										 		</div><?php } ?>
										 	<!--imagen post-->	
											 <li><a href="<?php the_permalink() ?>" rel="bookmark" title="Enlace permanente a <?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
										 </div>
									 <?php
									 endwhile;
									 }
									}
								?>
								<div class="ads_post_rela">
									<script type="text/javascript"><!--
									google_ad_client = "ca-pub-0318089046605103";
									/* anun theme wordpress post */
									google_ad_slot = "0626608783";
									google_ad_width = 234;
									google_ad_height = 60;
									//-->
									</script>
									<script type="text/javascript"
									src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
									</script>
								</div>
							
							</div>
					</div>
					<div id="navi">
						
						<div id="navi_izq"><div id="triangulo_izq"></div><?php previous_post_link(); ?></div>
						<div id="navi_der"><?php next_post_link(); ?><div id="triangulo_der"></div></div>
						
					</div>
					
							<div class="comments-template">
							<?php comments_template(); ?>
							</div>
						<?php endwhile; ?>
						
						<?php else : ?>
							 <h2 ><?php _e('Not Found', 'anp_creative');?></h2>
							 <p><?php _e('Apologies, but we were unable to find what you were looking for', 'anp_creative'); ?></p>
													
						<?php endif; ?>
										
					
				
							
			</article>
		<?php get_sidebar(); ?>		
		</div>				
<?php get_footer(); ?>