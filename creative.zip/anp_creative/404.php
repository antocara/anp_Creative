<?php get_header();?>
<div id="cont_ind_index">	
	<section id="cont_index">		
	<section id="content_404">
		<h1><?php _e('Error 404 - Not Found','anp_creative');?></h1>
		<p><?php _e('Apologies, but we were unable to find what you were looking for. Try different words or visit ','anp_creative');?><a href="<?php echo home_url();?>"><?php _e('the home page of the web.', 'anp_creative');?></a></p>
		<?php get_search_form();?>
		<div id="ulti_post">
			<h2><?php _e('It may be of interest','anp_creative');?> </h2>
			<ul>
			<?php
			$args = array( 'numberposts' => 9, 'orderby' => 'rand' );
			$rand_posts = get_posts( $args );
			foreach( $rand_posts as $post ) : ?>
				<div class="post_404">
					<li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
					<?php if(has_post_thumbnail()){ ?> <!--comprobamos que existe imagen principal en el post-->
						<div class="img_404">
							<?php the_post_thumbnail(array(150,180)); ?>
						</div><?php } ?>
				</div>	
			<?php endforeach; ?>
			</ul>
		</div>	
	</section>
	</section>
	<?php get_sidebar();?>
</div>	
<?php get_footer(); ?>